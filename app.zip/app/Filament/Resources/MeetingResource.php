<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MeetingResource\Pages;
use App\Filament\Resources\MeetingResource\RelationManagers;
use App\Features\Meetings\Models\Meeting;
use App\Features\Academic\Models\ClassGroup;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class MeetingResource extends Resource
{
    use \App\Filament\Concerns\ChecksResourcePermission;

    protected static ?string $model = Meeting::class;

    protected static ?string $navigationIcon = 'heroicon-o-calendar-days';
    protected static ?string $navigationGroup = 'Akademik (Ustad)';
    protected static ?string $navigationLabel = 'Jadwal & Absensi';
    protected static ?string $modelLabel = 'Jadwal & Absensi';
    protected static ?string $pluralModelLabel = 'Jadwal & Absensi';

    protected static function permission(): string
    {
        return 'meetings.manage';
    }

    // ==========================================================
    // FORM
    // ==========================================================

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Detail Pertemuan')
                    ->description('Pilih kelas dan isi topik pertemuan.')
                    ->icon('heroicon-o-calendar')
                    ->schema([
                        Forms\Components\Select::make('class_group_id')
                            ->relationship('classGroup', 'name')
                            ->label('Pilih Kelas')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->native(false)
                            ->live()
                            ->afterStateUpdated(function ($state, Forms\Set $set) {
                                if (! $state) {
                                    $set('students_attendance', []);
                                    return;
                                }

                                $classGroup = ClassGroup::find($state);

                                if (! $classGroup || ! $classGroup->students) {
                                    $set('students_attendance', []);
                                    return;
                                }

                                $attendanceData = [];

                                foreach ($classGroup->students as $student) {
                                    $attendanceData[] = [
                                        'user_id' => $student->id,
                                        'name' => $student->name,
                                        'status' => 'present',
                                    ];
                                }

                                $set('students_attendance', $attendanceData);
                            }),

                        Forms\Components\TextInput::make('title')
                            ->label('Topik / Materi')
                            ->placeholder('Contoh: Makhrajul Huruf Ba')
                            ->required()
                            ->maxLength(255),

                        Forms\Components\DatePicker::make('date')
                            ->label('Tanggal Pertemuan')
                            ->default(now())
                            ->required()
                            ->native(false)
                            ->displayFormat('d F Y')
                            ->maxDate(now()->addYear())
                            ->columnSpanFull(),

                        Forms\Components\Hidden::make('user_id')
                            ->default(fn () => Auth::id()),
                    ])
                    ->columns(2),

                // Section Absensi (muncul kalau kelas sudah dipilih)
                Forms\Components\Section::make('Daftar Kehadiran Santri')
                    ->description('Tentukan status kehadiran setiap santri.')
                    ->icon('heroicon-o-clipboard-document-check')
                    ->schema([
                        Forms\Components\Repeater::make('students_attendance')
                            ->hiddenLabel()
                            ->schema([
                                Forms\Components\Hidden::make('user_id'),

                                Forms\Components\TextInput::make('name')
                                    ->label('Nama Santri')
                                    ->disabled()
                                    ->columnSpan(2),

                                Forms\Components\ToggleButtons::make('status')
                                    ->label('Status Kehadiran')
                                    ->options([
                                        'present'    => 'Hadir',
                                        'sick'       => 'Sakit',
                                        'permission' => 'Izin',
                                        'alpha'      => 'Alpha',
                                    ])
                                    ->colors([
                                        'present'    => 'success',
                                        'sick'       => 'info',
                                        'permission' => 'warning',
                                        'alpha'      => 'danger',
                                    ])
                                    ->inline()
                                    ->required()
                                    ->columnSpan(2),
                            ])
                            ->columns(4)
                            ->addable(false)
                            ->deletable(false)
                            ->reorderable(false)
                            ->defaultItems(0),
                    ])
                    ->visible(fn (Forms\Get $get): bool => filled($get('class_group_id'))),

                // Info kosong kalau kelas belum dipilih
                Forms\Components\Section::make('Belum Ada Kelas Terpilih')
                    ->description('Silakan pilih kelas terlebih dahulu untuk menampilkan daftar kehadiran santri.')
                    ->icon('heroicon-o-information-circle')
                    ->schema([])
                    ->visible(fn (Forms\Get $get): bool => ! filled($get('class_group_id'))),
            ]);
    }

    // ==========================================================
    // TABLE
    // ==========================================================

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('classGroup.name')
                    ->label('Kelas')
                    ->sortable()
                    ->searchable()
                    ->badge()
                    ->color('info'),

                Tables\Columns\TextColumn::make('title')
                    ->label('Materi')
                    ->searchable()
                    ->weight('medium')
                    ->wrap()
                    ->limit(60),

                Tables\Columns\TextColumn::make('date')
                    ->label('Tanggal')
                    ->date('d M Y')
                    ->description(fn (Meeting $record): string =>
                        $record->date?->diffForHumans() ?? '')
                    ->sortable(),

                Tables\Columns\TextColumn::make('attendances_count')
                    ->counts('attendances')
                    ->label('Kehadiran')
                    ->badge()
                    ->color(fn (int $state): string => match (true) {
                        $state === 0 => 'gray',
                        $state < 3 => 'warning',
                        default => 'success',
                    })
                    ->icon('heroicon-m-users')
                    ->tooltip('Jumlah santri yang tercatat di absensi'),

                Tables\Columns\TextColumn::make('teacher.name')
                    ->label('Pengajar')
                    ->icon('heroicon-m-user-circle')
                    ->placeholder('—')
                    ->sortable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Dibuat')
                    ->dateTime('d M Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('class_group_id')
                    ->label('Kelas')
                    ->relationship('classGroup', 'name')
                    ->searchable()
                    ->preload()
                    ->multiple(),

                Tables\Filters\Filter::make('date')
                    ->form([
                        Forms\Components\DatePicker::make('from')
                            ->label('Dari Tanggal')
                            ->native(false),
                        Forms\Components\DatePicker::make('until')
                            ->label('Sampai Tanggal')
                            ->native(false),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when($data['from'], fn (Builder $q, $d) => $q->whereDate('date', '>=', $d))
                            ->when($data['until'], fn (Builder $q, $d) => $q->whereDate('date', '<=', $d));
                    })
                    ->label('Rentang Tanggal'),

                Tables\Filters\Filter::make('no_attendance')
                    ->label('Belum Ada Absensi')
                    ->query(fn (Builder $query): Builder => $query->doesntHave('attendances'))
                    ->toggle(),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->iconButton()
                    ->tooltip('Edit'),

                Tables\Actions\DeleteAction::make()
                    ->iconButton()
                    ->tooltip('Hapus')
                    ->requiresConfirmation()
                    ->modalHeading('Hapus Pertemuan?')
                    ->modalDescription(fn (Meeting $record): string =>
                        "Pertemuan \"{$record->title}\" beserta data absensinya akan dihapus permanen."
                    ),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('date', 'desc')
            ->striped()
            ->paginated([10, 25, 50])
            ->defaultPaginationPageOption(10)
            ->emptyStateHeading('Belum Ada Pertemuan')
            ->emptyStateDescription('Buat pertemuan pertama dengan klik tombol di atas.')
            ->emptyStateIcon('heroicon-o-calendar-days');
    }

    // ==========================================================
    // RELATIONS
    // ==========================================================

    public static function getRelations(): array
    {
        return [
            RelationManagers\AttendancesRelationManager::class,
        ];
    }

    // ==========================================================
    // QUERY FILTER PER ROLE
    // ==========================================================

    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery();
        $user = auth()->user();

        if ($user && $user->role === 'guru') {
            return $query->whereHas('classGroup', fn ($q) => $q->where('teacher_id', $user->id));
        }

        return $query;
    }

    // ==========================================================
    // AUTHORIZATION
    // ==========================================================

    public static function canView($record): bool
    {
        if (! static::canAccessAction('view')) {
            return false;
        }

        $user = auth()->user();
        if ($user && $user->role === 'guru') {
            return (int) $record->classGroup?->teacher_id === (int) $user->id;
        }

        return true;
    }

    public static function canEdit($record): bool
    {
        if (! static::canAccessAction('update')) {
            return false;
        }

        $user = auth()->user();
        if ($user && $user->role === 'guru') {
            return (int) $record->classGroup?->teacher_id === (int) $user->id;
        }

        return true;
    }

    public static function canDelete($record): bool
    {
        if (! static::canAccessAction('delete')) {
            return false;
        }

        $user = auth()->user();
        if ($user && $user->role === 'guru') {
            return (int) $record->classGroup?->teacher_id === (int) $user->id;
        }

        return true;
    }

    // ==========================================================
    // PAGES
    // ==========================================================

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMeetings::route('/'),
            'create' => Pages\CreateMeeting::route('/create'),
            'edit' => Pages\EditMeeting::route('/{record}/edit'),
        ];
    }
}