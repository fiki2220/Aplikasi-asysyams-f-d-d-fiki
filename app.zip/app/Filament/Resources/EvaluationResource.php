<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EvaluationResource\Pages;
use App\Features\Academic\Models\ClassGroup;
use App\Features\Grades\Models\Evaluation;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Grouping\Group;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class EvaluationResource extends Resource
{
    use \App\Filament\Concerns\ChecksResourcePermission;

    protected static ?string $model = Evaluation::class;

    protected static ?string $navigationIcon = 'heroicon-o-clipboard-document-check';
    protected static ?string $navigationGroup = 'Akademik (Ustad)';
    protected static ?string $navigationLabel = 'Input Evaluasi';
    protected static ?string $modelLabel = 'Evaluasi';
    protected static ?string $pluralModelLabel = 'Input Evaluasi';
    protected static ?int $navigationSort = 3;

    protected static function permission(): string
    {
        return 'evaluations.manage';
    }

    // ==========================================================
    // KONSTANTA
    // ==========================================================

    public const JENIS_OPTIONS = [
        'tilawah'  => 'Tilawah',
        'murottal' => 'Murottal',
    ];

    public const JENIS_COLORS = [
        'tilawah'  => 'success',
        'murottal' => 'info',
    ];

    public const JENIS_ICONS = [
        'tilawah'  => 'heroicon-m-book-open',
        'murottal' => 'heroicon-m-musical-note',
    ];

    // Maqra' Wajib untuk Tilawah
    public const MAQRA_WAJIB_OPTIONS = [
        "Ali 'Imran : 144" => "QS Ali 'Imran 144",
        "Qaf : 16"          => "QS Qaf 16",
        "At-Taubah : 81"    => "QS At-Taubah 81",
        "Al-Ma'idah : 27"   => "QS Al-Ma'idah 27",
        "Al-Isra : 1"       => "QS Al-Isra 1",
        "Al-A'raf : 31"     => "QS Al-A'raf 31",
    ];

    // Irama Murottal — 7 Maqom Utama
    public const IRAMA_MUROTTAL_OPTIONS = [
        'Bayyati'  => 'Maqom Bayyati',
        'Hijaz'    => 'Maqom Hijaz',
        'Nahwand'  => 'Maqom Nahwand',
        'Rast'     => 'Maqom Rast',
        'Sikah'    => 'Maqom Sikah',
        'Shoba'    => 'Maqom Shoba',
        'Jiharkah' => 'Maqom Jiharkah',
    ];

    // Maqom Lengkap untuk Tilawah (dengan sub-opsi)
    public const LAGU_OPTIONS = [
        'Maqom Bayyati' => [
            'Bayyati Awal Maqom'          => 'Awal Maqom',
            'Bayyati Qoror'                => 'Qoror',
            'Bayyati Nawa'                 => 'Nawa',
            'Bayyati Husaini'              => 'Husaini',
            'Bayyati Jawab'                => 'Jawab',
            'Bayyati Jawabul Jawab'        => 'Jawabul Jawab',
            'Bayyati Jawab Syuri'          => 'Jawab Syuri',
            'Bayyati Jawabul Jawab Syuri'  => 'Jawabul Jawab Syuri',
            'Bayyati Penutup'              => 'Penutup',
        ],
        'Maqom Hijaz' => [
            'Hijaz Awal Maqom'    => 'Awal Maqom',
            'Hijaz Jawab'         => 'Jawab',
            'Hijaz Jawabul Jawab' => 'Jawabul Jawab',
            'Hijaz Kar/Kur'       => 'Kar / Kur',
        ],
        'Maqom Nahwand' => [
            'Nahwand Awal Maqom'    => 'Awal Maqom',
            'Nahwand Jawab'         => 'Jawab',
            'Nahwand Jawabul Jawab' => 'Jawabul Jawab',
        ],
        'Maqom Rast' => [
            'Rast Awal Maqom'    => 'Awal Maqom',
            'Rast Jawab'         => 'Jawab',
            'Rast Jawabul Jawab' => 'Jawabul Jawab',
        ],
        'Maqom Sikah' => [
            'Sikah Awal Maqom'    => 'Awal Maqom',
            'Sikah Jawab'         => 'Jawab',
            'Sikah Jawabul Jawab' => 'Jawabul Jawab',
        ],
        'Maqom Shoba' => [
            'Shoba Awal Maqom'    => 'Awal Maqom',
            'Shoba Jawab'         => 'Jawab',
            'Shoba Jawabul Jawab' => 'Jawabul Jawab',
        ],
        'Maqom Jiharkah' => [
            'Jiharkah Awal Maqom'    => 'Awal Maqom',
            'Jiharkah Jawab'         => 'Jawab',
            'Jiharkah Jawabul Jawab' => 'Jawabul Jawab',
        ],
    ];

    // ==========================================================
    // HELPER
    // ==========================================================

    public static function maqomLabel(?string $kode): string
    {
        if (! $kode) return '—';

        if (isset(self::IRAMA_MUROTTAL_OPTIONS[$kode])) {
            return self::IRAMA_MUROTTAL_OPTIONS[$kode];
        }

        foreach (self::LAGU_OPTIONS as $group => $items) {
            if (isset($items[$kode])) {
                return "{$group} — {$items[$kode]}";
            }
        }

        return $kode;
    }

    protected static function getSurahData(): array
    {
        return Cache::remember('alquran_surah', 86400, function () {
            try {
                $response = Http::timeout(10)->get('https://equran.id/api/v2/surat');
                return $response->json()['data'] ?? [];
            } catch (\Throwable $e) {
                return [];
            }
        });
    }

    /**
     * ⭐ Konversi nilai tunggal → format `items` JSON
     */
    protected static function mergeNilaiToItems(array $data): array
    {
        $nilai = $data['nilai_evaluasi'] ?? null;

        if ($nilai !== null && $nilai !== '') {
            $data['items'] = [
                [
                    'name'   => 'Nilai Evaluasi',
                    'status' => 'Tercapai',
                    'score'  => (float) $nilai,
                ],
            ];
        } else {
            $data['items'] = null;
        }

        unset($data['nilai_evaluasi']);

        return $data;
    }

    /**
     * ⭐ Konversi `items` JSON → nilai tunggal untuk form
     */
    public static function mutateFormDataBeforeFill(array $data): array
    {
        $items = $data['items'] ?? null;

        if (is_string($items)) {
            $items = json_decode($items, true) ?? [];
        }

        if (is_array($items) && ! empty($items)) {
            $scores = array_filter(
                array_map(fn ($i) => $i['score'] ?? null, $items),
                fn ($s) => $s !== null && $s !== ''
            );

            $data['nilai_evaluasi'] = empty($scores)
                ? null
                : round(array_sum($scores) / count($scores), 2);
        } else {
            $data['nilai_evaluasi'] = null;
        }

        return $data;
    }

    public static function mutateFormDataBeforeCreate(array $data): array
    {
        return static::mergeNilaiToItems($data);
    }

    public static function mutateFormDataBeforeSave(array $data): array
    {
        return static::mergeNilaiToItems($data);
    }

    // ==========================================================
    // FORM
    // ==========================================================

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Informasi Evaluasi')
                    ->description('Pilih kelas, jenis evaluasi, dan santri.')
                    ->icon('heroicon-o-clipboard-document-check')
                    ->schema([
                        Forms\Components\Select::make('class_group_id')
                            ->label('Kelas')
                            ->options(ClassGroup::query()->pluck('name', 'id'))
                            ->required()
                            ->searchable()
                            ->preload()
                            ->native(false)
                            ->live(),

                        Forms\Components\Select::make('jenis')
                            ->label('Jenis Evaluasi')
                            ->options(self::JENIS_OPTIONS)
                            ->default('tilawah')
                            ->required()
                            ->native(false)
                            ->live()
                            ->helperText('Tilawah (Maqra\' Wajib) atau Murottal (Irama).'),

                        Forms\Components\Select::make('user_ids')
                            ->label('Pilih Santri (bisa pilih banyak)')
                            ->options(function (Forms\Get $get): array {
                                $classGroupId = $get('class_group_id');
                                if (! $classGroupId) return [];

                                return ClassGroup::find($classGroupId)
                                    ?->students()
                                    ->pluck('users.name', 'users.id')
                                    ->toArray() ?? [];
                            })
                            ->multiple()
                            ->required()
                            ->searchable()
                            ->preload()
                            ->native(false)
                            ->visible(fn (string $operation): bool => $operation === 'create')
                            ->helperText('Pilih lebih dari satu santri untuk input sekaligus.'),

                        Forms\Components\Select::make('user_id')
                            ->label('Santri')
                            ->options(function (Forms\Get $get): array {
                                $classGroupId = $get('class_group_id');
                                if (! $classGroupId) return [];

                                return ClassGroup::find($classGroupId)
                                    ?->students()
                                    ->pluck('users.name', 'users.id')
                                    ->toArray() ?? [];
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->native(false)
                            ->visible(fn (string $operation): bool => $operation === 'edit'),
                    ])
                    ->columns(2),

                Forms\Components\Section::make('Detail Evaluasi')
                    ->description('Isi detail sesuai jenis evaluasi yang dipilih.')
                    ->icon('heroicon-o-book-open')
                    ->schema([
                        // Tilawah: Maqra' Wajib
                        Forms\Components\Select::make('surah_name')
                            ->label('Maqra\' Wajib')
                            ->options(self::MAQRA_WAJIB_OPTIONS)
                            ->placeholder('— Pilih Maqra\' Wajib —')
                            ->searchable()
                            ->required()
                            ->native(false)
                            ->visible(fn (Forms\Get $get): bool => $get('jenis') === 'tilawah')
                            ->columnSpanFull()
                            ->helperText('Pilih salah satu dari 6 Maqra\' Wajib.'),

                        // Murottal: Surah bebas
                        Forms\Components\TextInput::make('surah_name')
                            ->label('Surah / Ayat')
                            ->placeholder('Contoh: Al-Baqarah 1-5')
                            ->required()
                            ->maxLength(150)
                            ->visible(fn (Forms\Get $get): bool => $get('jenis') === 'murottal')
                            ->columnSpanFull()
                            ->helperText('Tulis surah dan ayat bebas untuk Murottal.'),

                        // Tilawah: Maqom lengkap
                        Forms\Components\Select::make('song_name')
                            ->label('Maqom / Lagu')
                            ->options(self::LAGU_OPTIONS)
                            ->searchable()
                            ->native(false)
                            ->required()
                            ->visible(fn (Forms\Get $get): bool => $get('jenis') === 'tilawah')
                            ->columnSpanFull()
                            ->helperText('Pilih maqom lengkap dengan sub-opsi.'),

                        // Murottal: Irama 7 maqom utama
                        Forms\Components\Select::make('song_name')
                            ->label('Irama / Maqom')
                            ->options(self::IRAMA_MUROTTAL_OPTIONS)
                            ->placeholder('— Pilih Irama —')
                            ->native(false)
                            ->required()
                            ->visible(fn (Forms\Get $get): bool => $get('jenis') === 'murottal')
                            ->columnSpanFull()
                            ->helperText('Pilih salah satu dari 7 maqom utama.'),

                        // ⭐ Nilai Evaluasi (single field)
                        Forms\Components\TextInput::make('nilai_evaluasi')
                            ->label('Nilai Evaluasi')
                            ->numeric()
                            ->minValue(0)
                            ->maxValue(100)
                            ->step(0.01)
                            ->suffix('/ 100')
                            ->placeholder('Contoh: 92')
                            ->required()
                            ->columnSpanFull()
                            ->helperText('Masukkan nilai akhir evaluasi (0-100). Nilai ini akan digabung dengan nilai setoran di rapor.'),
                    ])
                    ->columns(1),
            ]);
    }

    // ==========================================================
    // INFOLIST
    // ==========================================================

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->schema([
                Infolists\Components\Section::make('Informasi Evaluasi')
                    ->icon('heroicon-o-clipboard-document-check')
                    ->schema([
                        Infolists\Components\TextEntry::make('classGroup.name')
                            ->label('Kelas')->badge()->color('info'),

                        Infolists\Components\TextEntry::make('student.name')
                            ->label('Nama Santri')->weight('bold')
                            ->icon('heroicon-m-user-circle'),

                        Infolists\Components\TextEntry::make('jenis')
                            ->label('Jenis Evaluasi')->badge()
                            ->formatStateUsing(fn (?string $state): string =>
                                self::JENIS_OPTIONS[$state] ?? ucfirst($state ?? '—'))
                            ->color(fn (?string $state): string =>
                                self::JENIS_COLORS[$state] ?? 'gray')
                            ->icon(fn (?string $state): string =>
                                self::JENIS_ICONS[$state] ?? 'heroicon-m-question-mark-circle'),

                        Infolists\Components\TextEntry::make('surah_name')
                            ->label(fn (Evaluation $record): string =>
                                $record->jenis === 'murottal' ? 'Surah / Ayat' : 'Maqra\' Wajib')
                            ->badge()->color('primary')
                            ->icon('heroicon-m-book-open')
                            ->placeholder('—'),

                        Infolists\Components\TextEntry::make('song_name')
                            ->label(fn (Evaluation $record): string =>
                                $record->jenis === 'murottal' ? 'Irama' : 'Lagu / Maqom')
                            ->badge()->color('success')
                            ->icon('heroicon-m-musical-note')
                            ->placeholder('—')
                            ->formatStateUsing(fn (?string $state): string => self::maqomLabel($state)),

                        // ⭐ Nilai Evaluasi
                        Infolists\Components\TextEntry::make('nilai_evaluasi')
                            ->label('Nilai Evaluasi')
                            ->badge()->color('warning')
                            ->icon('heroicon-m-star')
                            ->state(function (Evaluation $record): ?string {
                                $items = is_string($record->items)
                                    ? json_decode($record->items, true)
                                    : $record->items;
                                if (! is_array($items) || empty($items)) return null;

                                $scores = array_filter(
                                    array_map(fn ($i) => $i['score'] ?? null, $items),
                                    fn ($s) => $s !== null && $s !== ''
                                );
                                if (empty($scores)) return null;

                                $avg = round(array_sum($scores) / count($scores), 2);
                                return number_format($avg, 2) . ' / 100';
                            })
                            ->placeholder('—'),

                        Infolists\Components\TextEntry::make('created_at')
                            ->label('Dibuat')->dateTime('d M Y H:i')
                            ->since()->color('gray'),
                    ])
                    ->columns(3),
            ]);
    }

    // ==========================================================
    // TABLE
    // ==========================================================

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('classGroup.name')
                    ->label('Kelas')
                    ->badge()->color('info')
                    ->icon('heroicon-m-academic-cap')
                    ->sortable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('jenis')
                    ->label('Jenis')->badge()
                    ->formatStateUsing(fn (?string $state): string =>
                        self::JENIS_OPTIONS[$state] ?? ucfirst($state ?? '—'))
                    ->color(fn (?string $state): string =>
                        self::JENIS_COLORS[$state] ?? 'gray')
                    ->icon(fn (?string $state): string =>
                        self::JENIS_ICONS[$state] ?? 'heroicon-m-question-mark-circle')
                    ->sortable(),

                Tables\Columns\TextColumn::make('surah_name')
                    ->label('Surah / Maqra\'')
                    ->searchable()
                    ->limit(30)->placeholder('—')
                    ->icon('heroicon-m-book-open'),

                Tables\Columns\TextColumn::make('song_name')
                    ->label('Maqom / Irama')
                    ->searchable()
                    ->formatStateUsing(fn (?string $state): string => self::maqomLabel($state))
                    ->limit(35)->placeholder('—')
                    ->icon('heroicon-m-musical-note'),

                // ⭐ Kolom Nilai Evaluasi
                Tables\Columns\TextColumn::make('nilai_evaluasi')
                    ->label('Nilai')
                    ->badge()->color('warning')
                    ->icon('heroicon-m-star')
                    ->alignCenter()
                    ->state(function (Evaluation $record): ?float {
                        $items = is_string($record->items)
                            ? json_decode($record->items, true)
                            : $record->items;
                        if (! is_array($items) || empty($items)) return null;

                        $scores = array_filter(
                            array_map(fn ($i) => $i['score'] ?? null, $items),
                            fn ($s) => $s !== null && $s !== ''
                        );
                        if (empty($scores)) return null;

                        return round(array_sum($scores) / count($scores), 2);
                    })
                    ->formatStateUsing(fn ($state): string =>
                        $state !== null ? number_format((float) $state, 2) : '—'),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Dibuat')
                    ->dateTime('d M Y H:i')
                    ->description(fn (Evaluation $record): string =>
                        $record->created_at?->diffForHumans() ?? '')
                    ->sortable(),
            ])
            ->defaultGroup('student.name')
            ->groups([
                Group::make('student.name')
                    ->label('Santri')
                    ->collapsible()
                    ->getTitleFromRecordUsing(fn (Evaluation $record): string =>
                        ($record->student?->name ?? '—')
                        . ' — ' . ($record->classGroup?->name ?? '—'))
                    ->getDescriptionFromRecordUsing(fn (Evaluation $record): string =>
                        'Kelas: ' . ($record->classGroup?->name ?? '—')
                        . ' • NISN: ' . ($record->student?->nisn ?? '—')),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('jenis')
                    ->label('Jenis Evaluasi')
                    ->options(self::JENIS_OPTIONS),

                Tables\Filters\SelectFilter::make('class_group_id')
                    ->label('Kelas')->relationship('classGroup', 'name')
                    ->searchable()->preload()->multiple(),
            ])
            ->actions([
                Tables\Actions\ViewAction::make()
                    ->iconButton()->tooltip('Lihat Detail')->modalWidth('4xl'),

                Tables\Actions\EditAction::make()
                    ->iconButton()->tooltip('Edit'),

                Tables\Actions\DeleteAction::make()
                    ->iconButton()->tooltip('Hapus')
                    ->requiresConfirmation()
                    ->modalHeading('Hapus Evaluasi?')
                    ->modalDescription(fn (Evaluation $record): string =>
                        "Evaluasi untuk \"{$record->student?->name}\" akan dihapus permanen."),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('user_id', 'asc')
            ->striped()
            ->paginated([25, 50, 100])
            ->defaultPaginationPageOption(25)
            ->emptyStateHeading('Belum Ada Evaluasi')
            ->emptyStateDescription('Input evaluasi santri dengan klik tombol di atas.')
            ->emptyStateIcon('heroicon-o-clipboard-document-check')
            ->emptyStateActions([
                Tables\Actions\CreateAction::make()
                    ->label('Input Evaluasi')->icon('heroicon-o-plus'),
            ]);
    }

    // ==========================================================
    // QUERY
    // ==========================================================

    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery();
        $user = auth()->user();

        if ($user && $user->role === 'guru') {
            return $query->whereHas('classGroup', fn ($q) => $q->where('teacher_id', $user->id));
        }
        return $query;
    }

    // ==========================================================
    // AUTHORIZATION
    // ==========================================================

    public static function canView($record): bool
    {
        if (! static::canAccessAction('view')) return false;
        $user = auth()->user();
        if ($user && $user->role === 'guru') {
            return (int) $record->classGroup?->teacher_id === (int) $user->id;
        }
        return true;
    }

    public static function canEdit($record): bool
    {
        if (! static::canAccessAction('update')) return false;
        $user = auth()->user();
        if ($user && $user->role === 'guru') {
            return (int) $record->classGroup?->teacher_id === (int) $user->id;
        }
        return true;
    }

    public static function canDelete($record): bool
    {
        if (! static::canAccessAction('delete')) return false;
        $user = auth()->user();
        if ($user && $user->role === 'guru') {
            return (int) $record->classGroup?->teacher_id === (int) $user->id;
        }
        return true;
    }

    // ==========================================================
    // PAGES
    // ==========================================================

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListEvaluations::route('/'),
            'create' => Pages\CreateEvaluation::route('/create'),
            'view'   => Pages\ViewEvaluation::route('/{record}'),
            'edit'   => Pages\EditEvaluation::route('/{record}/edit'),
        ];
    }
}