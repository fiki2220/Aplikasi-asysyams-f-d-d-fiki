<?php

namespace App\Filament\Resources\EvaluationResource\Pages;

use App\Filament\Resources\EvaluationResource;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;

class EditEvaluation extends EditRecord
{
    protected static string $resource = EvaluationResource::class;

    // ==========================================================
    // HEADER ACTIONS
    // ==========================================================

    protected function getHeaderActions(): array
    {
        return [
            Actions\ViewAction::make()
                ->label('Lihat')->icon('heroicon-o-eye'),

            Actions\DeleteAction::make()
                ->label('Hapus')->icon('heroicon-o-trash')
                ->requiresConfirmation()
                ->modalHeading('Hapus Evaluasi?')
                ->modalDescription(fn () =>
                    "Evaluasi untuk \"{$this->record->student?->name}\" akan dihapus permanen.")
                ->modalSubmitActionLabel('Ya, Hapus'),
        ];
    }

    // ==========================================================
    // PASTIKAN field `jenis` terisi
    // ==========================================================

    protected function mutateFormDataBeforeFill(array $data): array
    {
        // ⭐ Pastikan jenis ada (default: tilawah untuk data lama)
        $data['jenis'] = $data['jenis'] ?? 'tilawah';

        return $data;
    }

    // ==========================================================
    // FORM ACTIONS
    // ==========================================================

    protected function getSaveFormAction(): Actions\Action
    {
        return parent::getSaveFormAction()
            ->label('💾 Simpan Perubahan')->color('success');
    }

    protected function getCancelFormAction(): Actions\Action
    {
        return parent::getCancelFormAction()
            ->label('Batal')
            ->url($this->getResource()::getUrl('index'));
    }

    // ==========================================================
    // NOTIFIKASI
    // ==========================================================

    protected function getSavedNotification(): ?Notification
    {
        $jenis = EvaluationResource::JENIS_OPTIONS[$this->record->jenis] ?? '-';

        if ($this->record->jenis === 'murottal') {
            $maqom = EvaluationResource::maqomLabel($this->record->song_name);
            $detail = "Jenis: {$jenis}\nSurah: " . ($this->record->surah_name ?? '-')
                    . "\nIrama: {$maqom}";
        } else {
            $detail = "Jenis: {$jenis}\nMaqra' Wajib: " . ($this->record->surah_name ?? '-')
                    . "\nMaqom: " . EvaluationResource::maqomLabel($this->record->song_name);
        }

        return Notification::make()
            ->success()
            ->title('✅ Perubahan Berhasil Disimpan')
            ->body("Evaluasi untuk \"{$this->record->student?->name}\"\n\n{$detail}")
            ->duration(4000);
    }

    // ==========================================================
    // REDIRECT & TITLE
    // ==========================================================

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }

    public function getTitle(): string
    {
        return "Edit Evaluasi • {$this->record->student?->name}";
    }

    public function getSubheading(): ?string
    {
        if (! $this->record) return null;

        $class = $this->record->classGroup?->name ?? '-';
        $jenis = EvaluationResource::JENIS_OPTIONS[$this->record->jenis] ?? '-';

        return "{$class} • Jenis: {$jenis}";
    }
}