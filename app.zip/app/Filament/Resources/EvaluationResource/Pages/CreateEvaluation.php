<?php

namespace App\Filament\Resources\EvaluationResource\Pages;

use App\Filament\Resources\EvaluationResource;
use App\Features\Grades\Models\Evaluation;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Database\Eloquent\Model;

class CreateEvaluation extends CreateRecord
{
    protected static string $resource = EvaluationResource::class;

    public int $createdCount = 0;

    // ==========================================================
    // HANDLE BATCH CREATE
    // ==========================================================

    protected function handleRecordCreation(array $data): Model
    {
        $userIds = $data['user_ids'] ?? [];
        $firstRecord = null;
        $this->createdCount = 0;

        $jenis = $data['jenis'] ?? 'tilawah';

        foreach ($userIds as $userId) {
            // ⭐ AUTO-INCREMENT per (kelas + santri + jenis)
            $lastNumber = Evaluation::where('class_group_id', $data['class_group_id'])
                ->where('user_id', $userId)
                ->where('jenis', $jenis)
                ->max('evaluation_number') ?? 0;

            $record = Evaluation::create([
                'class_group_id'    => $data['class_group_id'],
                'user_id'           => $userId,
                'jenis'             => $jenis,
                'evaluation_number' => $lastNumber + 1,
                'surah_name'        => $data['surah_name'] ?? null,
                'song_name'         => $data['song_name'] ?? null,
                'items'             => $data['items'] ?? [],
            ]);

            $this->createdCount++;

            if (! $firstRecord) {
                $firstRecord = $record;
            }
        }

        return $firstRecord;
    }

    // ==========================================================
    // FORM ACTIONS
    // ==========================================================

    protected function getCreateFormAction(): Actions\Action
    {
        return parent::getCreateFormAction()
            ->label('💾 Simpan Evaluasi')
            ->color('success');
    }

    protected function getCreateAnotherFormAction(): Actions\Action
    {
        return parent::getCreateAnotherFormAction()
            ->label('Simpan & Tambah Lagi');
    }

    protected function getCancelFormAction(): Actions\Action
    {
        return parent::getCancelFormAction()
            ->label('Batal')
            ->url($this->getResource()::getUrl('index'));
    }

    // ==========================================================
    // NOTIFIKASI
    // ==========================================================

    protected function getCreatedNotification(): ?Notification
    {
        $count = $this->createdCount ?: 1;
        $class = $this->record->classGroup?->name ?? '-';
        $jenis = EvaluationResource::JENIS_OPTIONS[$this->record->jenis] ?? '-';

        $title = $count > 1
            ? "{$count} santri di kelas {$class} berhasil diberi evaluasi."
            : "Santri \"{$this->record->student?->name}\" berhasil diberi evaluasi.";

        if ($this->record->jenis === 'murottal') {
            $maqom = EvaluationResource::maqomLabel($this->record->song_name);
            $detail = "Jenis: {$jenis}\nSurah: " . ($this->record->surah_name ?? '-')
                    . "\nIrama: {$maqom}";
        } else {
            $detail = "Jenis: {$jenis}\nMaqra' Wajib: " . ($this->record->surah_name ?? '-')
                    . "\nMaqom: " . EvaluationResource::maqomLabel($this->record->song_name);
        }

        return Notification::make()
            ->success()
            ->title('✅ Evaluasi Berhasil Disimpan')
            ->body($title . "\n\n" . $detail)
            ->duration(6000);
    }

    // ==========================================================
    // REDIRECT
    // ==========================================================

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }

    public function getTitle(): string
    {
        return 'Input Evaluasi Baru';
    }
}