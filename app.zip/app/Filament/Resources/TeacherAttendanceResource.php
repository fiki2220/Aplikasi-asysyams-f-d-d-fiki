<?php

namespace App\Filament\Resources;

use App\Features\TeacherAttendances\Models\TeacherAttendance;
use App\Filament\Resources\TeacherAttendanceResource\Pages;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class TeacherAttendanceResource extends Resource
{
    use \App\Filament\Concerns\ChecksResourcePermission;

    protected static ?string $model = TeacherAttendance::class;

    protected static ?string $navigationIcon = 'heroicon-o-clipboard-document-check';
    protected static ?string $navigationGroup = 'Akademik (Ustad)';
    protected static ?string $navigationLabel = 'Absensi Ustad';
    protected static ?string $modelLabel = 'Absensi Ustad';
    protected static ?string $pluralModelLabel = 'Absensi Ustad';
    protected static ?int $navigationSort = 3;

    protected static function permission(): string
    {
        return 'teacher-attendances.manage';
    }

    // ==========================================================
    // QUERY — Filter otomatis per role
    // ==========================================================

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->when(
                Auth::user()?->role !== 'superadmin',
                fn (Builder $query): Builder => $query->where('user_id', Auth::id())
            );
    }

    // ==========================================================
    // FORM — dengan default value & auto-fill
    // ==========================================================

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Informasi Absensi')
                    ->description('Detail kehadiran ustad/guru. Status & waktu check-in otomatis terisi.')
                    ->icon('heroicon-o-clipboard-document-check')
                    ->schema([
                        Forms\Components\Select::make('user_id')
                            ->label('Guru / Ustad')
                            ->options(fn (): array => User::query()
                                ->where('role', 'guru')
                                ->orderBy('name')
                                ->pluck('name', 'id')
                                ->all())
                            ->searchable()
                            ->preload()
                            ->required()
                            ->native(false),

                        Forms\Components\DatePicker::make('date')
                            ->label('Tanggal')
                            ->default(now())
                            ->required()
                            ->native(false)
                            ->displayFormat('d F Y')
                            ->maxDate(now()),

                        // ⭐ Auto-fill jam sekarang saat tambah absensi
                        Forms\Components\DateTimePicker::make('check_in_at')
                            ->label('Waktu Check In')
                            ->default(fn (string $operation) => $operation === 'create' ? now() : null)
                            ->native(false)
                            ->displayFormat('d F Y H:i')
                            ->seconds(false)
                            ->helperText('Otomatis terisi dengan waktu sekarang.'),

                        Forms\Components\DateTimePicker::make('check_out_at')
                            ->label('Waktu Check Out')
                            ->native(false)
                            ->displayFormat('d F Y H:i')
                            ->seconds(false)
                            ->afterOrEqual('check_in_at')
                            ->helperText('Kosongkan jika ustad belum check-out.'),

                        // ⭐ Default "Hadir" — tidak wajib pilih manual
                        Forms\Components\Select::make('status')
                            ->label('Status Kehadiran')
                            ->options(TeacherAttendance::STATUSES)
                            ->default('present')
                            ->required()
                            ->native(false)
                            ->helperText('Default "Hadir". Ubah jika perlu koreksi.'),

                        Forms\Components\Select::make('created_by')
                            ->label('Dibuat Oleh')
                            ->relationship('creator', 'name')
                            ->default(fn () => Auth::id())
                            ->disabled()
                            ->dehydrated()
                            ->nullable(),

                        Forms\Components\Textarea::make('note')
                            ->label('Catatan')
                            ->placeholder('Catatan tambahan (opsional)')
                            ->rows(3)
                            ->maxLength(1000)
                            ->columnSpanFull(),
                    ])
                    ->columns(2),
            ]);
    }

    // ==========================================================
    // INFOLIST
    // ==========================================================

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->schema([
                Infolists\Components\Section::make('Data Kehadiran')
                    ->icon('heroicon-o-clipboard-document-check')
                    ->schema([
                        Infolists\Components\TextEntry::make('user.name')
                            ->label('Guru / Ustad')
                            ->weight('bold')
                            ->icon('heroicon-m-user-circle'),

                        Infolists\Components\TextEntry::make('date')
                            ->label('Tanggal')
                            ->date('d F Y'),

                        Infolists\Components\TextEntry::make('check_in_at')
                            ->label('Check In')
                            ->dateTime('H:i')
                            ->placeholder('—')
                            ->icon('heroicon-m-arrow-right-end-on-rectangle')
                            ->color('success'),

                        Infolists\Components\TextEntry::make('check_out_at')
                            ->label('Check Out')
                            ->dateTime('H:i')
                            ->placeholder('—')
                            ->icon('heroicon-m-arrow-left-start-on-rectangle')
                            ->color('danger'),

                        Infolists\Components\TextEntry::make('status')
                            ->label('Status')
                            ->badge()
                            ->formatStateUsing(fn (?string $state): string =>
                                TeacherAttendance::STATUSES[$state] ?? $state)
                            ->color(fn (?string $state): string => match ($state) {
                                'present' => 'success',
                                'late' => 'warning',
                                'permission' => 'info',
                                'sick' => 'gray',
                                'alpha' => 'danger',
                                default => 'gray',
                            }),

                        Infolists\Components\TextEntry::make('creator.name')
                            ->label('Dicatat Oleh')
                            ->placeholder('—'),

                        Infolists\Components\TextEntry::make('note')
                            ->label('Catatan')
                            ->placeholder('—')
                            ->columnSpanFull(),

                        Infolists\Components\TextEntry::make('created_at')
                            ->label('Waktu Dibuat')
                            ->dateTime('d M Y H:i')
                            ->since()
                            ->color('gray'),
                    ])
                    ->columns(2),
            ]);
    }

    // ==========================================================
    // TABLE
    // ==========================================================

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('date', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('date')
                    ->label('Tanggal')
                    ->date('d M Y')
                    ->description(fn (TeacherAttendance $record): string =>
                        $record->date?->diffForHumans() ?? '')
                    ->sortable()
                    ->weight('medium'),

                Tables\Columns\TextColumn::make('user.name')
                    ->label('Nama Guru')
                    ->searchable()
                    ->sortable()
                    ->weight('semibold')
                    ->icon('heroicon-m-user-circle'),

                Tables\Columns\TextColumn::make('check_in_at')
                    ->label('Check In')
                    ->dateTime('H:i')
                    ->placeholder('—')
                    ->icon('heroicon-m-arrow-right-end-on-rectangle')
                    ->color('success')
                    ->sortable(),

                Tables\Columns\TextColumn::make('check_out_at')
                    ->label('Check Out')
                    ->dateTime('H:i')
                    ->placeholder('—')
                    ->icon('heroicon-m-arrow-left-start-on-rectangle')
                    ->color('danger')
                    ->sortable(),

                Tables\Columns\TextColumn::make('duration')
                    ->label('Durasi')
                    ->getStateUsing(function (TeacherAttendance $record): string {
                        if (! $record->check_in_at || ! $record->check_out_at) {
                            return '—';
                        }

                        $minutes = Carbon::parse($record->check_in_at)
                            ->diffInMinutes(Carbon::parse($record->check_out_at));

                        $hours = floor($minutes / 60);
                        $mins = $minutes % 60;

                        return $hours > 0
                            ? "{$hours}j {$mins}m"
                            : "{$mins}m";
                    })
                    ->badge()
                    ->color('info')
                    ->toggleable(),

                Tables\Columns\TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->formatStateUsing(fn (?string $state): string =>
                        TeacherAttendance::STATUSES[$state] ?? $state)
                    ->color(fn (?string $state): string => match ($state) {
                        'present' => 'success',
                        'late' => 'warning',
                        'permission' => 'info',
                        'sick' => 'gray',
                        'alpha' => 'danger',
                        default => 'gray',
                    })
                    ->icon(fn (?string $state): string => match ($state) {
                        'present' => 'heroicon-m-check-circle',
                        'late' => 'heroicon-m-clock',
                        'permission' => 'heroicon-m-document-text',
                        'sick' => 'heroicon-m-heart',
                        'alpha' => 'heroicon-m-x-circle',
                        default => 'heroicon-m-question-mark-circle',
                    })
                    ->sortable(),

                Tables\Columns\TextColumn::make('note')
                    ->label('Catatan')
                    ->limit(40)
                    ->wrap()
                    ->placeholder('—')
                    ->tooltip(fn (TeacherAttendance $record): ?string => $record->note)
                    ->toggleable(isToggledHiddenByDefault: true),

                Tables\Columns\TextColumn::make('creator.name')
                    ->label('Dicatat Oleh')
                    ->icon('heroicon-m-user')
                    ->placeholder('—')
                    ->toggleable(isToggledHiddenByDefault: true),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Dibuat')
                    ->dateTime('d M Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\Filter::make('date')
                    ->form([
                        Forms\Components\DatePicker::make('date')
                            ->label('Tanggal')
                            ->native(false),
                    ])
                    ->query(fn (Builder $query, array $data): Builder => $query
                        ->when(
                            $data['date'] ?? null,
                            fn (Builder $q, string $d): Builder => $q->whereDate('date', $d)
                        ))
                    ->indicateUsing(fn (array $data): ?string =>
                        $data['date']
                            ? 'Tanggal: ' . Carbon::parse($data['date'])->format('d M Y')
                            : null),

                Tables\Filters\SelectFilter::make('user_id')
                    ->label('Guru')
                    ->relationship('user', 'name', fn (Builder $query): Builder =>
                        $query->where('role', 'guru'))
                    ->searchable()
                    ->preload()
                    ->multiple(),

                Tables\Filters\SelectFilter::make('status')
                    ->label('Status Kehadiran')
                    ->options(TeacherAttendance::STATUSES)
                    ->multiple(),

                Tables\Filters\Filter::make('this_month')
                    ->label('Bulan Ini')
                    ->query(fn (Builder $query): Builder => $query
                        ->whereMonth('date', now()->month)
                        ->whereYear('date', now()->year))
                    ->toggle(),
            ])
            ->actions([
                Tables\Actions\ViewAction::make()
                    ->iconButton()
                    ->tooltip('Lihat Detail')
                    ->modalWidth('2xl'),

                Tables\Actions\EditAction::make()
                    ->iconButton()
                    ->tooltip('Edit'),

                Tables\Actions\DeleteAction::make()
                    ->iconButton()
                    ->tooltip('Hapus')
                    ->requiresConfirmation(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->striped()
            ->paginated([10, 25, 50, 100])
            ->defaultPaginationPageOption(10)
            ->recordClasses(fn (TeacherAttendance $record): ?string => match ($record->status) {
                'late' => 'bg-amber-50 dark:bg-amber-950/20',
                'alpha' => 'bg-red-50 dark:bg-red-950/20',
                'present' => 'bg-green-50 dark:bg-green-950/10',
                default => null,
            })
            ->emptyStateHeading('Belum Ada Data Absensi')
            ->emptyStateDescription('Data absensi ustad akan muncul di sini setelah ada yang check-in.')
            ->emptyStateIcon('heroicon-o-clipboard-document-check')
            ->emptyStateActions([
                Tables\Actions\CreateAction::make()
                    ->label('Tambah Absensi')
                    ->icon('heroicon-o-plus'),
            ]);
    }

    // ==========================================================
    // PAGES
    // ==========================================================

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTeacherAttendances::route('/'),
            'create' => Pages\CreateTeacherAttendance::route('/create'),
            'view' => Pages\ViewTeacherAttendance::route('/{record}'),
            'edit' => Pages\EditTeacherAttendance::route('/{record}/edit'),
        ];
    }
}