<?php

namespace App\Features\Payments\Services;

use App\Features\Academic\Models\Semester;
use App\Features\Payments\Models\Payment;
use App\Models\User;
use Illuminate\Support\Str;

class PaymentGeneratorService
{
    /**
     * Generate tagihan untuk 1 user di semester tertentu.
     * Return Payment record (existing atau baru). Null kalau tidak ada semester aktif.
     */
    public function generateForUser(User $user, ?Semester $semester = null): ?Payment
    {
        $semester = $semester ?? Semester::where('is_active', true)->first();

        if (! $semester) {
            return null;
        }

        // Kalau sudah ada tagihan untuk user+semester ini, tidak generate lagi
        $existing = Payment::query()
            ->where('user_id', $user->id)
            ->where('semester_id', $semester->id)
            ->first();

        if ($existing) {
            return $existing;
        }

        return Payment::create([
            'user_id'     => $user->id,
            'semester_id' => $semester->id,
            'amount'      => $semester->tuition_fee,
            'status'      => 'pending',
            'order_id'    => $this->generateOrderId($user, $semester),
        ]);
    }

    /**
     * Generate tagihan untuk SEMUA siswa aktif di semester tertentu.
     * Return jumlah tagihan baru yang dibuat.
     */
    public function generateForAllStudents(?Semester $semester = null): int
    {
        $semester = $semester ?? Semester::where('is_active', true)->first();

        if (! $semester) {
            return 0;
        }

        $students = User::query()
            ->where('role', 'student')
            ->where('is_active', true)
            ->get();

        $count = 0;

        foreach ($students as $student) {
            $payment = $this->generateForUser($student, $semester);

            if ($payment && $payment->wasRecentlyCreated) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * Generate order_id unik.
     */
    protected function generateOrderId(User $user, Semester $semester): string
    {
        $base = 'SPP-' . $semester->id . '-' . $user->id . '-' . now()->format('YmdHis');

        if (Payment::where('order_id', $base)->exists()) {
            $base .= '-' . Str::random(4);
        }

        return $base;
    }
}