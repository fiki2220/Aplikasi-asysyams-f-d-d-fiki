<?php

use App\Features\Academic\Models\ClassGroup;
use App\Features\Contacts\Controllers\ContactController;
use App\Features\Grades\Controllers\GradeReportController;
use App\Features\Payments\Controllers\PaymentController;
use App\Features\Posts\Controllers\PostController;
use App\Features\Posts\Models\Post;
use App\Features\SiteSettings\Models\SiteSetting;
use App\Features\Students\Controllers\StudentController;
use App\Features\Reports\Controllers\RaporVerificationController;
use App\Features\TeacherAttendances\Controllers\TeacherAttendanceController;
use App\Http\Middleware\EnsureUserHasPermission;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Carbon\Carbon;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Struktur:
|   A. Halaman Publik (tanpa login)
|   B. Halaman Auth Dasar (login required)
|   C. Route File PPDB (dengan proteksi berlapis)
|   D. Halaman User Login (dengan permission)
|   E. Webhook & Public POST
|   F. Debug Routes (local only)
|
*/

// ==========================================================
// A. HALAMAN PUBLIK
// ==========================================================

// 1. Landing Page
Route::get('/', function () {
    $heroBg = null;
    $bgUrl = null;

    try {
        if (class_exists(SiteSetting::class)) {
            $heroBg = SiteSetting::where('key', 'hero_bg')->value('value');
        }
    } catch (\Throwable $e) {
        $heroBg = null;
    }

    // Ambil 3 berita terbaru
    $posts = collect();
    try {
        if (class_exists(Post::class)) {
            $posts = Post::where('is_published', true)
                ->whereNotNull('published_at')
                ->where('published_at', '<=', now())
                ->with('author')
                ->latest('published_at')
                ->take(3)
                ->get();
        }
    } catch (\Throwable $e) {
        $posts = collect();
    }

    // Deadline countdown
    $deadline = now()->endOfYear()->format('Y-m-d H:i:s');
    try {
        if (class_exists(SiteSetting::class)) {
            $setting = SiteSetting::where('key', 'spmb_deadline')->value('value');
            if ($setting) {
                $deadline = $setting;
            }
        }
    } catch (\Throwable $e) {
        // skip
    }

    $deadlineISO = Carbon::parse($deadline)->format('Y-m-d\TH:i:s');

    return view('pages.home', compact('bgUrl', 'posts', 'deadline', 'deadlineISO'));
})->name('home');

// ⭐ 1b. Halaman SPMB (Penerimaan Peserta Didik Baru)
Route::view('/spmb', 'pages.spmb')->name('spmb.index');

// 2. Daftar Berita
Route::get('/news', function () {
    $posts = new LengthAwarePaginator(
        [],
        0,
        9,
        request('page', 1),
        ['path' => request()->url()]
    );

    try {
        if (class_exists(Post::class)) {
            $posts = Post::where('is_published', true)
                ->whereNotNull('published_at')
                ->where('published_at', '<=', now())
                ->with('author')
                ->latest('published_at')
                ->paginate(9);
        }
    } catch (\Throwable $e) {
        // skip
    }

    return view('pages.news', compact('posts'));
})->name('news.index');

// 3. Detail Berita
Route::get('/berita/{slug}', [PostController::class, 'show'])->name('post.show');

// 4. Kirim Pesan Kontak
Route::post('/contact/send', [ContactController::class, 'send'])->name('contact.send');

// 5. Verifikasi Rapor (publik — tanpa login)
Route::get('/verify/rapor/{token}', [RaporVerificationController::class, 'show'])
    ->name('rapor.verify');

// ==========================================================
// B. HALAMAN AUTH DASAR (login required)
// ==========================================================

// Menunggu verifikasi akun
Route::middleware(['auth'])->group(function () {
    Route::get('/approval', fn () => view('pages.approval'))->name('approval.notice');
    Route::get('/registration/pending', fn () => view('pages.approval'))->name('registration.pending');
    Route::get('/access-denied', fn () => view('pages.access-denied'))->name('access.denied');
});

// ==========================================================
// C. ROUTE FILE PPDB — PROTEKSI BERLAPIS
// ==========================================================
// Dokumen (KK, Akta, Ijazah, Foto) bersifat PRIVAT.
//
// Proteksi:
//   1. Harus login
//   2. Hanya pemilik file ATAU admin/superadmin
//   3. Anti directory traversal
//   4. Cek file exist
// ==========================================================
Route::get('/ppdb-file/{path}', function (string $path) {
    // 1. PROTEKSI: harus login
    if (! auth()->check()) {
        abort(403, 'Anda harus login untuk mengakses dokumen ini.');
    }

    // 2. SANITASI PATH
    $safePath = str_replace(['..', '\\', '//'], '', $path);
    $fullPath = 'ppdb-documents/' . ltrim($safePath, '/');

    // 3. PROTEKSI: hanya pemilik atau admin
    $user = auth()->user();

    $isAdmin = $user->isAdmin()
        || $user->isSuperadmin()
        || $user->hasAccess('users.view')
        || $user->hasAccess('users.manage');

    $isOwner = in_array($fullPath, array_filter([
        $user->file_kk,
        $user->file_akta,
        $user->file_ijazah,
        $user->file_foto,
    ]), true);

    if (! $isAdmin && ! $isOwner) {
        abort(403, 'Anda tidak berhak mengakses dokumen ini.');
    }

    // 4. CEK FILE ADA
    if (! Storage::disk('public')->exists($fullPath)) {
        abort(404, 'File tidak ditemukan.');
    }

    // 5. STREAM FILE
    return Storage::disk('public')->response($fullPath);
})
    ->where('path', '.*')
    ->name('ppdb.file');

// ==========================================================
// D. HALAMAN USER LOGIN (dengan permission)
// ==========================================================

Route::middleware(['auth', 'verified', 'is_active'])->group(function () {

    // ─────────────────────────────────────────
    // Dashboard & Profil
    // ─────────────────────────────────────────
    Route::get('/dashboard', [StudentController::class, 'dashboard'])->name('dashboard');

    // ⭐ Halaman Pembayaran terpisah
    Route::get('/pembayaran', [StudentController::class, 'payment'])->name('student.payment');
    Route::get('/profile', [StudentController::class, 'profile'])->name('profile');
    Route::match(['put', 'patch'], '/profile', [StudentController::class, 'updateProfile'])
        ->name('profile.update');

    // ─────────────────────────────────────────
    // Transkrip & Absensi
    // ─────────────────────────────────────────
    Route::get('/transcript', [StudentController::class, 'transcript'])
        ->middleware(EnsureUserHasPermission::class . ':reports.view')
        ->name('student.transcript');

    Route::get('/attendance', [StudentController::class, 'attendance'])
        ->middleware(EnsureUserHasPermission::class . ':dashboard.view')
        ->name('student.attendance');

    // ─────────────────────────────────────────
    // Absensi Guru
    // ─────────────────────────────────────────
    Route::post('/teacher-attendances/check-in', [TeacherAttendanceController::class, 'checkIn'])
        ->middleware(EnsureUserHasPermission::class . ':teacher-attendances.check-in')
        ->name('teacher-attendances.check-in');

    Route::post('/teacher-attendances/check-out', [TeacherAttendanceController::class, 'checkOut'])
        ->middleware(EnsureUserHasPermission::class . ':teacher-attendances.check-in')
        ->name('teacher-attendances.check-out');

    // ─────────────────────────────────────────
    // Payment Midtrans
    // ─────────────────────────────────────────
    Route::get('/payment/checkout', [PaymentController::class, 'checkout'])
        ->middleware(EnsureUserHasPermission::class . ':payments.checkout')
        ->name('payment.checkout');

    Route::get('/payment/success', [PaymentController::class, 'success'])
        ->name('payment.success');

    // ─────────────────────────────────────────
    // Kwitansi Pembayaran
    // ─────────────────────────────────────────
    Route::get('/kwitansi/{payment}/pdf', [PaymentController::class, 'kwitansiPdf'])
        ->name('payment.kwitansi.pdf');

    Route::get('/kwitansi/{payment}/print', [PaymentController::class, 'kwitansiPrint'])
        ->name('payment.kwitansi.print');

    // ─────────────────────────────────────────
    // Laporan Kontrol Santri (Tabel Nilai)
    // ⚠️ Ditaruh DI ATAS route Filament untuk hindari konflik
    // ─────────────────────────────────────────
    Route::get('/grades-control/{user}', [GradeReportController::class, 'show'])
        ->middleware(EnsureUserHasPermission::class . ':grades.view|grades.manage')
        ->name('admin.grades.student-control');

    Route::get('/grades-control/{user}/pdf', [GradeReportController::class, 'pdf'])
        ->middleware(EnsureUserHasPermission::class . ':grades.view|grades.manage')
        ->name('admin.grades.student-control.pdf');
});

// ==========================================================
// E. WEBHOOK & PUBLIC POST
// ==========================================================

// Webhook Midtrans (tanpa CSRF)
Route::post('/payment/webhook', [PaymentController::class, 'webhook'])
    ->withoutMiddleware([\Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class])
    ->name('payment.webhook');

// ==========================================================
// F. CETAK RAPOR PDF (Santri) — dengan Filter Periode
// ==========================================================

// Single santri
Route::get('/rapor-pdf/{class_group}/{user}', [GradeReportController::class, 'raporSingle'])
    ->middleware(['auth', EnsureUserHasPermission::class . ':reports.download'])
    ->name('rapor.pdf');

// Bulk: ZIP semua santri dalam 1 kelas
Route::get('/rapor-pdf-kelas/{class_group}', [GradeReportController::class, 'raporClass'])
    ->middleware(['auth', EnsureUserHasPermission::class . ':reports.download'])
    ->name('rapor.pdf.class');

// ==========================================================
// G. DEBUG ROUTES (HANYA LOCAL)
// ==========================================================

if (app()->environment('local')) {

    Route::get('/check-db', function () {
        try {
            DB::connection()->getPdo();

            return response()->json([
                'status' => 'Database connected!',
                'users_count' => DB::table('users')->count(),
                'migrations_count' => DB::table('migrations')->count(),
                'database_name' => config('database.connections.mysql.database'),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage(),
                'database_name' => config('database.connections.mysql.database'),
            ], 500);
        }
    });

    Route::get('/clear-cache-sekarang', function () {
        Artisan::call('optimize:clear');
        Artisan::call('cache:clear');
        Artisan::call('route:clear');
        Artisan::call('view:clear');
        Artisan::call('config:clear');
        Artisan::call('filament:clear-cached-components');

        return 'Mantap! Semua cache Laravel dan Filament berhasil dibersihkan. Silakan buka /admin sekarang.';
    });

    Route::get('/cek-rute', function () {
        Artisan::call('route:list', ['--path' => 'admin']);
        return '<pre>' . Artisan::output() . '</pre>';
    });

    Route::get('/cek-pintu', function () {
        try {
            $url = route('filament.admin.auth.login');

            return "<h3>Sistem Laravel mendeteksi halaman login ada di link ini:</h3>
                    <a href='{$url}' style='font-size:20px; font-weight:bold; color:blue;'>KLIK DI SINI UNTUK LOGIN</a>
                    <br><br>
                    <p>Kalau diklik masih 404, berarti ada yang memblokir dari luar Laravel.</p>";
        } catch (\Exception $e) {
            return 'Terjadi error: ' . $e->getMessage();
        }
    });
}

require __DIR__ . '/auth.php';