<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\asysyams-f-d-d\Aplikasi-asysyams-f-d-d\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>