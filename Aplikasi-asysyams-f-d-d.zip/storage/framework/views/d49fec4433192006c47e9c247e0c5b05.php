<?php
    // Load logo sebagai base64 agar tidak tergantung HTTP request
    $logoSrc = null;
    try {
        $logoPath = public_path('images/logo.PNG');
        if (file_exists($logoPath)) {
            $logoData = file_get_contents($logoPath);
            $logoSrc = 'data:image/png;base64,' . base64_encode($logoData);
        }
    } catch (\Exception $e) {
        $logoSrc = null;
    }
?>

<?php echo $__env->make('grades.student-control-screen-style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('grades.student-control-table', ['logoSrc' => $logoSrc], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\asysyams-f-d-d\Aplikasi-asysyams-f-d-d\resources\views/grades/student-control-modal.blade.php ENDPATH**/ ?>