<?php
    $className = $classGroup?->name ?? '-';
    $semesterName = $classGroup?->semester?->name;
    $classDisplay = collect([$className, $semesterName])->filter()->implode(' / ');

    $displayRows = collect($rows);
    $count = $displayRows->count();

    // ⭐ LOGIKA BARIS KOSONG
    if ($count >= 15) {
        $emptyRows = 0;
        $isDataEmpty = false;
    } elseif ($count === 0) {
        $emptyRows = 15;
        $isDataEmpty = true;
    } else {
        $emptyRows = 15 - $count;
        $isDataEmpty = false;
    }

    $colWidths = $colWidths ?? [
        'no'      => '4%',
        'date'    => '9%',
        'reading' => '21%',
        'mark'    => '3%',
        'sign'    => '6%',
    ];

    $markNum = (int) filter_var($colWidths['mark'], FILTER_SANITIZE_NUMBER_INT);
    $unit    = preg_replace('/[0-9.]/', '', $colWidths['mark']) ?: '%';
    $markTotal3 = ($markNum * 3) . $unit;
    $markTotal2 = ($markNum * 2) . $unit;
?>

<div class="student-control-sheet">
    <div class="sheet-header">
        <div class="logo-cell">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($logoSrc)): ?>
                <img src="<?php echo e($logoSrc); ?>" alt="Logo Asy-Syams">
            <?php else: ?>
                <div class="logo-fallback">ASY<br>SYAMS</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="brand-cell">
            <div class="brand-title"><?php echo e($institution['name']); ?></div>
            <div class="brand-subtitle"><?php echo e($institution['subtitle']); ?></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($institution['address']) || ! empty($institution['phone']) || ! empty($institution['email'])): ?>
                <div class="brand-contact">
                    <?php echo e(collect([$institution['address'], $institution['phone'], $institution['email']])->filter()->implode(' | ')); ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <div class="top-rule"></div>

    <div class="identity-row">
        <div class="identity-field">
            <span class="identity-label">Nama</span>
            <span class="identity-colon">:</span>
            <span class="identity-value"><?php echo e($student->name); ?></span>
        </div>
        <div class="identity-field identity-class">
            <span class="identity-label">Kelas</span>
            <span class="identity-colon">:</span>
            <span class="identity-value"><?php echo e($classDisplay); ?></span>
        </div>
    </div>

    <table class="control-table">
        <colgroup>
            <col style="width: <?php echo e($colWidths['no']); ?>">
            <col style="width: <?php echo e($colWidths['date']); ?>">
            <col style="width: <?php echo e($colWidths['reading']); ?>">
            <col style="width: <?php echo e($colWidths['mark']); ?>">
            <col style="width: <?php echo e($colWidths['mark']); ?>">
            <col style="width: <?php echo e($colWidths['mark']); ?>">
            <col style="width: <?php echo e($colWidths['reading']); ?>">
            <col style="width: <?php echo e($colWidths['mark']); ?>">
            <col style="width: <?php echo e($colWidths['mark']); ?>">
            <col style="width: <?php echo e($colWidths['reading']); ?>">
            <col style="width: <?php echo e($colWidths['sign']); ?>">
        </colgroup>

        <thead>
            <tr>
                <th rowspan="2" style="width: <?php echo e($colWidths['no']); ?>;">NO</th>
                <th rowspan="2" style="width: <?php echo e($colWidths['date']); ?>;">TANGGAL</th>
                <th rowspan="2" style="width: <?php echo e($colWidths['reading']); ?>;">ZIYADAH</th>
                <th colspan="3" style="width: <?php echo e($markTotal3); ?>;">KET</th>
                <th rowspan="2" style="width: <?php echo e($colWidths['reading']); ?>;">MUROJAAH</th>
                <th colspan="2" style="width: <?php echo e($markTotal2); ?>;">KET</th>
                <th rowspan="2" style="width: <?php echo e($colWidths['reading']); ?>;">TAHSIN</th>
                <th rowspan="2" style="width: <?php echo e($colWidths['sign']); ?>;">TTD</th>
            </tr>
            <tr>
                <th style="width: <?php echo e($colWidths['mark']); ?>;">L</th>
                <th style="width: <?php echo e($colWidths['mark']); ?>;">C</th>
                <th style="width: <?php echo e($colWidths['mark']); ?>;">TL</th>
                <th style="width: <?php echo e($colWidths['mark']); ?>;">B</th>
                <th style="width: <?php echo e($colWidths['mark']); ?>;">K</th>
            </tr>
        </thead>

        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $displayRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($row['number']); ?></td>
                    <td class="text-center">
                        <?php echo e($row['date'] ? $row['date']->format('d/m/Y') : ''); ?>

                    </td>
                    <td><?php echo e($row['ziyadah'] ?: ''); ?></td>
                    <td class="text-center mark-cell"><?php echo e($row['ziyadah_score'] === 'L' ? '✓' : ''); ?></td>
                    <td class="text-center mark-cell"><?php echo e($row['ziyadah_score'] === 'C' ? '✓' : ''); ?></td>
                    <td class="text-center mark-cell"><?php echo e($row['ziyadah_score'] === 'TL' ? '✓' : ''); ?></td>
                    <td><?php echo e($row['murojaah'] ?: ''); ?></td>
                    <td class="text-center mark-cell"><?php echo e($row['murojaah_score'] === 'B' ? '✓' : ''); ?></td>
                    <td class="text-center mark-cell"><?php echo e($row['murojaah_score'] === 'K' ? '✓' : ''); ?></td>
                    <td><?php echo e($row['tahsin'] ?: ''); ?></td>

                    
                    <td class="text-center ttd-initials" title="<?php echo e($row['creator_name'] ?? ''); ?>">
                        <?php echo e($row['creator_initials'] ?? '—'); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isDataEmpty): ?>
                <tr>
                    <td colspan="11" class="empty-state">Belum ada data assessment untuk santri ini.</td>
                </tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < $emptyRows; $i++): ?>
                <tr class="blank-row">
                    <td>&nbsp;</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
    </table>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($creatorLegend)): ?>
        <div class="creator-legend">
            <strong>Keterangan TTD:</strong>
            <ul>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $creatorLegend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $initials => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><strong><?php echo e($initials); ?></strong> = <?php echo e($name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="summary-section note-section">
        <div class="summary-title">CATATAN PEMBELAJARAN</div>
        <table class="summary-table note-table">
            <thead>
                <tr>
                    <th style="width: 12%;">Tanggal</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $learningNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $learningNote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $notesList = $learningNote['notes'] ?? []; ?>
                    <tr>
                        <td class="text-center" style="vertical-align: top;">
                            <?php echo e($learningNote['date']?->format('d/m/Y') ?? '—'); ?>

                        </td>
                        <td style="vertical-align: top;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($notesList) > 1): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $notesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="margin-bottom: 2px;">
                                        &bull; <?php echo e($note); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php elseif(count($notesList) === 1): ?>
                                <?php echo e($notesList[0]); ?>

                            <?php else: ?>
                                <?php echo e($learningNote['note'] ?? '—'); ?>

                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2" class="empty-state">Belum ada catatan pembelajaran.</td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="notes">
        <div>Keterangan:</div>
        <ol>
            <li>Beri tanda centang (✓) pada kolom keterangan.</li>
            <li>Kolom Ziyadah: Lancar (L), Cukup (C), Tidak Lancar (TL).</li>
            <li>Kolom Murojaah: Baik (B), Kurang (K).</li>
        </ol>
    </div>

    
    <div class="summary-section">
        <div class="summary-title">EVALUASI</div>
        <table class="summary-table evaluation-table">
            <thead>
                <tr>
                    <th style="width: 22%;">Surah / Ayat</th>
                    <th style="width: 22%;">Lagu / Irama</th>
                    <th style="width: 30%;">Catatan / Item</th>
                    <th style="width: 10%;">Nilai</th>
                    <th style="width: 16%;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $evaluationSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($evaluation['surah_name'] ?? '—'); ?></td>
                        <td><?php echo e($evaluation['song_name'] ?? '—'); ?></td>
                        <td><?php echo e($evaluation['item'] ?? '—'); ?></td>
                        <td class="text-center"><?php echo e($evaluation['score'] ?? '—'); ?></td>
                        <td class="text-center"><?php echo e($evaluation['status'] ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="empty-state">Belum ada data evaluasi.</td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="summary-section">
        <div class="summary-title">REKAP ABSENSI</div>
        <table class="summary-table attendance-table">
            <thead>
                <tr>
                    <th>Hadir</th>
                    <th>Sakit</th>
                    <th>Izin</th>
                    <th>Alpha</th>
                    <th>Total</th>
                    <th>Persentase</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center"><?php echo e($attendanceSummary['present']); ?></td>
                    <td class="text-center"><?php echo e($attendanceSummary['sick']); ?></td>
                    <td class="text-center"><?php echo e($attendanceSummary['permission']); ?></td>
                    <td class="text-center"><?php echo e($attendanceSummary['alpha']); ?></td>
                    <td class="text-center"><?php echo e($attendanceSummary['total']); ?></td>
                    <td class="text-center"><?php echo e($attendanceSummary['percentage']); ?>%</td>
                </tr>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\asysyams-f-d-d\Aplikasi-asysyams-f-d-d\resources\views/grades/student-control-table.blade.php ENDPATH**/ ?>